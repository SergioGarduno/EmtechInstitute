
""""
Login del usuario
usuario: admin
contraseña: admin
"""
#Variable acceso para determinar el estado del login, F = no acceso T = acceso. Intentos es para contar el numero de intenos para acceder, el maximo sera de 3 intentos
acceso = False
intentos = 0
#Mensaje bienvenida
print("Hola bienvenido\nIngresa tus credenciales para acceder")

#while loop para hacer login
#not acceso cambia el estado a true hasta hacer el login correcto
while not acceso:
  usuario = input('Usuario: ')
  contras = input('Contraseña del usuario: ')
  
  if (contras != 'admin') or (usuario != 'admin'):
    intentos += 1
    restantes = 3 - intentos
    print(f'Credenciales incorrectas\nTienes "{restantes}" intentos restantes' ) 
    if restantes == 0:
      print('Error, intentos excedidos')
      exit()
  else:
    acceso = True




